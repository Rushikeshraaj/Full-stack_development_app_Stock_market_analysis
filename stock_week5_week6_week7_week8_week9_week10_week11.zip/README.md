# Stock Market Analysis Platform

A React + Vite learning project built week-by-week for Full Stack Development I.

## Week 5 — Project Review and Navigation
- Uses React Router for Home, Markets, Watchlist and Portfolio pages.
- Navigation uses `NavLink`, including an active route style.
- Includes a fallback page for unknown routes.

## Week 6 — Advanced Hooks (useContext / useReducer)
- `src/context/MarketContext.jsx` provides shared market data and watchlist state.
- `useReducer` handles `ADD` and `REMOVE` actions.
- `useContext` lets Markets, Watchlist and Portfolio access shared state without prop drilling.
- Add stocks from Markets and remove them from Watchlist.

## Week 7 — API Integration, Node.js Fundamentals
- Introduced a backend server and HTTP/JSON responses.
- Added `GET /api/health` as a health-check endpoint.
- Added `GET /api/stocks` for sample stock data.

## Week 8 — Express.js and Routing
- Replaced the basic Node HTTP handler with an Express application.
- Added `express.json()` middleware to read JSON request bodies.
- Created `backend/routes/stocks.js` and mounted it at `/api/stocks`.
- `GET /api/stocks` returns all sample stock records.
- `POST /api/stocks` validates and adds a stock, returning HTTP 201.
- Invalid POST data returns HTTP 400; unknown paths return HTTP 404.
- Stock records are held in memory and reset when the server restarts.


## Week 9 — MongoDB and Mongoose
- Added `backend/config/database.js` to connect to MongoDB using Mongoose.
- Added `backend/models/Stock.js` with validation for symbol and price, plus change, volume, sector and update timestamps.
- Updated `GET /api/stocks` and `POST /api/stocks` to use MongoDB when connected, while retaining the Week 8 in-memory fallback if `MONGODB_URI` is not configured.
- Added `backend/.env.example` for local MongoDB or MongoDB Atlas configuration.
- Stock symbols are stored in uppercase and must be unique; invalid prices return HTTP 400 and duplicate symbols return HTTP 409.

### Enable MongoDB for Week 9
1. Install backend dependencies with `cd backend` and `npm install`.
2. Copy `.env.example` to `.env` and set `MONGODB_URI` to your local MongoDB or Atlas connection string.
3. Run `npm start`. When the database connection succeeds, stock records are saved persistently and remain after server restarts.
4. Keep `.env` private and never commit database passwords or connection strings to GitHub.

## Week 10 — REST API Development
- Completed CRUD operations: `GET /api/stocks`, `GET /api/stocks/:id`, `POST /api/stocks`, `PUT /api/stocks/:id`, and `DELETE /api/stocks/:id`.
- Added `GET /api/stocks/gainers` and `GET /api/stocks/losers`, sorted by percentage change.
- Added symbol and sector filters with query parameters, for example `/api/stocks?symbol=TCS` or `/api/stocks?sector=IT`.
- Added validation and consistent error responses, including HTTP 400 for invalid input, 404 for missing records, and 409 for duplicate symbols.
- CRUD routes work with MongoDB/Mongoose when connected and use the in-memory fallback otherwise. In-memory changes reset when the server restarts.

### Week 10 API examples
- `GET http://localhost:5000/api/stocks/gainers`
- `GET http://localhost:5000/api/stocks/losers`
- `GET http://localhost:5000/api/stocks/1` (in-memory fallback)
- `PUT http://localhost:5000/api/stocks/1` with JSON body such as `{"price": 2900, "change": 1.8}`
- `DELETE http://localhost:5000/api/stocks/1`

For MongoDB mode, use the stock document's MongoDB `_id` for `GET`, `PUT`, and `DELETE`.

## Run the frontend
```bash
npm install
npm run dev
```

## Run the backend
In a separate terminal:
```bash
cd backend
npm install
npm start
```

Try these endpoints in a browser or API client:
- `GET http://localhost:5000/api/health`
- `GET http://localhost:5000/api/stocks`
- `POST http://localhost:5000/api/stocks` with JSON body, for example:
```json
{
  "symbol": "HDFCBANK",
  "price": 1650.5,
  "change": 0.7,
  "volume": "1.5M"
}
```

## GitHub commit suggestion
`Integrated React frontend with backend API using Axios (Week 11)`


## Week 11 — Front-end / Back-end Integration & Deployment
- Added Axios and connected the React application to `GET /api/stocks`.
- The frontend reads the API base URL from `VITE_API_URL`; if it is not set, it uses `http://localhost:5000`.
- Added loading and API-unavailable messages. If the backend cannot be reached, the app continues to display sample data.
- Backend CORS middleware permits the frontend to call the API during local development.
- Added a root `.env.example` for frontend configuration. Never commit real secrets or private environment files.

### Week 11 local integration steps
1. In the project root, run `npm install`.
2. Copy `.env.example` to `.env` (or create `.env`) and set `VITE_API_URL=http://localhost:5000`.
3. In terminal 1, run `cd backend`, `npm install`, then `npm start`. Configure `backend/.env` with `MONGODB_URI` if you want persistent database storage.
4. In terminal 2 from the project root, run `npm run dev`.
5. Open the Vite URL shown in the terminal and visit the Markets page. The frontend should request stock records from the backend.

### Deployment checklist
- Deploy the backend folder to a Node.js host such as Render and set its environment variables (including `MONGODB_URI` if needed).
- Deploy the frontend project to Vercel or another static host. Set `VITE_API_URL` to the deployed backend base URL in the hosting dashboard, then rebuild/redeploy.
- Confirm the backend health check at `/api/health` and test `/api/stocks`. Restrict CORS to the deployed frontend origin before production use.
- Deployment is a checklist only; this repository has not been deployed by this code change.
