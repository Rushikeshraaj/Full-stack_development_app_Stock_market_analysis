// Weeks 8-10: Express routes, MongoDB persistence, and full CRUD for stocks.
const express = require('express');
const mongoose = require('mongoose');
const Stock = require('../models/Stock');
const router = express.Router();

// In-memory fallback keeps the API usable when MongoDB is not configured.
const sampleStocks = [
  { id: 1, symbol: 'RELIANCE', price: 2850.5, change: 1.25, volume: '2.4M', sector: 'Energy' },
  { id: 2, symbol: 'TCS', price: 3920.75, change: -0.45, volume: '1.1M', sector: 'IT' },
  { id: 3, symbol: 'INFY', price: 1680.2, change: 0.85, volume: '3.2M', sector: 'IT' }
];

const isDatabaseConnected = () => mongoose.connection.readyState === 1;
const validPrice = value => value !== undefined && Number.isFinite(Number(value)) && Number(value) >= 0;
const validId = id => mongoose.Types.ObjectId.isValid(id);

// GET /api/stocks/gainers — stocks with positive change, highest first.
router.get('/gainers', async (req, res) => {
  try {
    const stocks = isDatabaseConnected()
      ? await Stock.find({ change: { $gt: 0 } }).sort({ change: -1 })
      : sampleStocks.filter(stock => Number(stock.change) > 0).sort((a, b) => b.change - a.change);
    return res.json(stocks);
  } catch (error) {
    return res.status(500).json({ message: 'Unable to fetch gainers', error: error.message });
  }
});

// GET /api/stocks/losers — stocks with negative change, lowest first.
router.get('/losers', async (req, res) => {
  try {
    const stocks = isDatabaseConnected()
      ? await Stock.find({ change: { $lt: 0 } }).sort({ change: 1 })
      : sampleStocks.filter(stock => Number(stock.change) < 0).sort((a, b) => a.change - b.change);
    return res.json(stocks);
  } catch (error) {
    return res.status(500).json({ message: 'Unable to fetch losers', error: error.message });
  }
});

// GET /api/stocks?symbol=TCS&sector=IT — list and optional filtering.
router.get('/', async (req, res) => {
  try {
    const { symbol, sector } = req.query;
    if (isDatabaseConnected()) {
      const filter = {};
      if (symbol) filter.symbol = String(symbol).trim().toUpperCase();
      if (sector) filter.sector = new RegExp(`^${String(sector).trim()}$`, 'i');
      return res.json(await Stock.find(filter).sort({ symbol: 1 }));
    }
    let stocks = [...sampleStocks];
    if (symbol) stocks = stocks.filter(stock => stock.symbol === String(symbol).trim().toUpperCase());
    if (sector) stocks = stocks.filter(stock => stock.sector.toLowerCase() === String(sector).trim().toLowerCase());
    return res.json(stocks);
  } catch (error) {
    return res.status(500).json({ message: 'Unable to fetch stocks', error: error.message });
  }
});

// GET /api/stocks/:id — fetch one stock by MongoDB ID or fallback numeric ID.
router.get('/:id', async (req, res) => {
  try {
    let stock;
    if (isDatabaseConnected()) {
      if (!validId(req.params.id)) return res.status(400).json({ message: 'Invalid stock ID' });
      stock = await Stock.findById(req.params.id);
    } else {
      stock = sampleStocks.find(item => String(item.id) === req.params.id);
    }
    if (!stock) return res.status(404).json({ message: 'Stock not found' });
    return res.json(stock);
  } catch (error) {
    return res.status(500).json({ message: 'Unable to fetch stock', error: error.message });
  }
});

// POST /api/stocks — create a stock.
router.post('/', async (req, res) => {
  const { symbol, price } = req.body || {};
  if (!symbol || !validPrice(price)) {
    return res.status(400).json({ message: 'A symbol and a valid non-negative numeric price are required' });
  }
  const stockData = {
    symbol: String(symbol).trim().toUpperCase(),
    price: Number(price),
    change: Number(req.body.change || 0),
    volume: req.body.volume ? String(req.body.volume) : 'N/A',
    sector: req.body.sector ? String(req.body.sector) : 'Unknown',
    lastUpdated: new Date()
  };
  try {
    if (isDatabaseConnected()) return res.status(201).json(await Stock.create(stockData));
    if (sampleStocks.some(stock => stock.symbol === stockData.symbol)) {
      return res.status(409).json({ message: 'A stock with this symbol already exists' });
    }
    const stock = { id: Date.now(), ...stockData };
    sampleStocks.push(stock);
    return res.status(201).json(stock);
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: 'A stock with this symbol already exists' });
    if (error.name === 'ValidationError') return res.status(400).json({ message: error.message });
    return res.status(500).json({ message: 'Unable to save stock', error: error.message });
  }
});

// PUT /api/stocks/:id — update an existing stock.
router.put('/:id', async (req, res) => {
  const updates = {};
  for (const field of ['symbol', 'price', 'change', 'volume', 'sector']) {
    if (req.body && req.body[field] !== undefined) updates[field] = req.body[field];
  }
  if (updates.symbol !== undefined) updates.symbol = String(updates.symbol).trim().toUpperCase();
  if (updates.price !== undefined) {
    if (!validPrice(updates.price)) return res.status(400).json({ message: 'Price must be a valid non-negative number' });
    updates.price = Number(updates.price);
  }
  if (updates.change !== undefined && !Number.isFinite(Number(updates.change))) {
    return res.status(400).json({ message: 'Change must be numeric' });
  }
  if (updates.change !== undefined) updates.change = Number(updates.change);
  updates.lastUpdated = new Date();
  try {
    let stock;
    if (isDatabaseConnected()) {
      if (!validId(req.params.id)) return res.status(400).json({ message: 'Invalid stock ID' });
      stock = await Stock.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    } else {
      const index = sampleStocks.findIndex(item => String(item.id) === req.params.id);
      if (index !== -1) {
        sampleStocks[index] = { ...sampleStocks[index], ...updates };
        stock = sampleStocks[index];
      }
    }
    if (!stock) return res.status(404).json({ message: 'Stock not found' });
    return res.json(stock);
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: 'A stock with this symbol already exists' });
    if (error.name === 'ValidationError') return res.status(400).json({ message: error.message });
    return res.status(500).json({ message: 'Unable to update stock', error: error.message });
  }
});

// DELETE /api/stocks/:id — remove an existing stock.
router.delete('/:id', async (req, res) => {
  try {
    let stock;
    if (isDatabaseConnected()) {
      if (!validId(req.params.id)) return res.status(400).json({ message: 'Invalid stock ID' });
      stock = await Stock.findByIdAndDelete(req.params.id);
    } else {
      const index = sampleStocks.findIndex(item => String(item.id) === req.params.id);
      if (index !== -1) stock = sampleStocks.splice(index, 1)[0];
    }
    if (!stock) return res.status(404).json({ message: 'Stock not found' });
    return res.json({ message: 'Stock deleted successfully', stock });
  } catch (error) {
    return res.status(500).json({ message: 'Unable to delete stock', error: error.message });
  }
});

module.exports = router;
