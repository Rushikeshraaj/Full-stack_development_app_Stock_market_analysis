// Week 9: Connect the Express backend to MongoDB using Mongoose.
const mongoose = require('mongoose');

async function connectDatabase() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.log('MONGODB_URI is not set. Running with Week 8 in-memory sample data.');
    return false;
  }

  try {
    await mongoose.connect(uri);
    console.log('Connected to MongoDB successfully.');
    return true;
  } catch (error) {
    console.error('MongoDB connection failed:', error.message);
    throw error;
  }
}

module.exports = connectDatabase;
