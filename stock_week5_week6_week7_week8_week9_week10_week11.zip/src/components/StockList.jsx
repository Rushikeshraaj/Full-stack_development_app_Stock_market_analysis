import StockCard from './StockCard';
import { useMarket } from '../context/MarketContext';

function StockList() {
  const { stocks, watchlist, dispatch, loading, apiMessage } = useMarket();
  const addStock = (stock) => dispatch({ type: 'ADD', stock });
  return (
    <>
      {loading && <p role="status">Loading stocks from the API...</p>}
      {apiMessage && <p className="api-status" role="status">{apiMessage}</p>}
      <div className="stock-list">
        {stocks.map((stock) => (
          <StockCard key={stock.symbol} {...stock}
            actionLabel={watchlist.some((item) => item.symbol === stock.symbol) ? 'Added ✓' : 'Add to Watchlist'}
            onAction={() => addStock(stock)}
            disabled={watchlist.some((item) => item.symbol === stock.symbol)}
          />
        ))}
      </div>
    </>
  );
}
export default StockList;
