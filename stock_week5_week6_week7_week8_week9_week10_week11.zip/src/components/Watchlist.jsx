import StockCard from './StockCard';

const watchlistStocks = [
  { symbol: 'WIPRO', price: 480.3, change: 0.6, volume: '1.5M' },
  { symbol: 'SBIN', price: 780.9, change: -0.3, volume: '5.1M' },
  { symbol: 'BHARTIARTL', price: 1450.0, change: 1.8, volume: '1.9M' },
];

function Watchlist() {
  return (
    <div className="stock-list">
      {watchlistStocks.map((stock) => (
        <StockCard
          key={stock.symbol}
          symbol={stock.symbol}
          price={stock.price}
          change={stock.change}
          volume={stock.volume}
        />
      ))}
    </div>
  );
}

export default Watchlist;
