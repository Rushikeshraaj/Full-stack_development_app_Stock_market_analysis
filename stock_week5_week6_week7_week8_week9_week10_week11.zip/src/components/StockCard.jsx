function StockCard({ symbol, price, change, volume, actionLabel, onAction, disabled = false }) {
  const isPositive = change >= 0;
  return (
    <div className="stock-card">
      <div>
        <h3>{symbol}</h3>
        <p>Price: ₹{Number(price).toLocaleString('en-IN', { maximumFractionDigits: 2 })}</p>
        <p>Volume: {volume}</p>
      </div>
      <div>
        <p className={isPositive ? 'up' : 'down'}>{isPositive ? '+' : ''}{change}%</p>
        {onAction && <button type="button" onClick={onAction} disabled={disabled}>{actionLabel}</button>}
      </div>
    </div>
  );
}
export default StockCard;
