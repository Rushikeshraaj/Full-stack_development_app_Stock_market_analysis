import { useMarket } from '../context/MarketContext';

function Portfolio() {
  const { watchlist } = useMarket();
  const total = watchlist.reduce((sum, stock) => sum + Number(stock.price), 0);
  return (
    <section>
      <h2>Portfolio Overview</h2>
      <p>Number of tracked stocks: <strong>{watchlist.length}</strong></p>
      <p>Combined displayed stock price: <strong>₹{total.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</strong></p>
      <p>This is a learning/demo value based on watchlist prices, not an investment valuation.</p>
    </section>
  );
}
export default Portfolio;
