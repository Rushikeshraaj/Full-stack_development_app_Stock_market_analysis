import StockCard from '../components/StockCard';
import { useMarket } from '../context/MarketContext';

function WatchlistPage() {
  const { watchlist, dispatch } = useMarket();
  return (
    <section>
      <h2>My Watchlist</h2>
      <p>Stocks saved for quick tracking: {watchlist.length}</p>
      {watchlist.length === 0 ? <p>No stocks yet. Visit Markets and add a stock.</p> : (
        <div className="stock-list">
          {watchlist.map((stock) => (
            <StockCard key={stock.symbol} {...stock} actionLabel="Remove"
              onAction={() => dispatch({ type: 'REMOVE', symbol: stock.symbol })} />
          ))}
        </div>
      )}
    </section>
  );
}
export default WatchlistPage;
